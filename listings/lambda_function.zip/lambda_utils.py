# import boto3
# from django.conf import settings
# from boto3.dynamodb.conditions import Key, Attr
# import logging

# # Initialize DynamoDB client
# dynamodb = boto3.resource('dynamodb', region_name='us-east-1')  # Specify your AWS region
# notifications_table = dynamodb.Table('Notifications')  # Your DynamoDB table name
# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger(__name__)

# def get_user_notifications(user_id):
#     """
#     Fetch unread notifications for a specific user from DynamoDB.
#     """
#     try:
#         # Query DynamoDB for notifications that match the user_id and are unread
#         response = notifications_table.query(
#             KeyConditionExpression=Key('user_id').eq(user_id),
#             FilterExpression=Attr('is_read').eq(False)
#         )
#         notifications = response.get('Items', [])
        
#         # Log the number of notifications found
#         print(f"Fetched {len(notifications)} unread notifications for user {user_id}.")
#         return notifications

#     except Exception as e:
#         print(f"Error fetching notifications: {e}")
#         return []


# def mark_notifications_as_read(user_id):
#     """
#     Marks all unread notifications for a specific user as read.
#     """
#     try:
#         # Query for unread notifications
#         response = notifications_table.scan(
#             FilterExpression=Key('user_id').eq(user_id) & Attr('is_read').eq(False)
#         )
        
#         for notification in response.get('Items', []):
#             # Update each notification's `is_read` attribute to True
#             notifications_table.update_item(
#                 Key={
#                     'user_id': user_id,
#                     'notification_id': notification['notification_id']
#                 },
#                 UpdateExpression="SET is_read = :val",
#                 ExpressionAttributeValues={':val': True}
#             )
#         logger.info("Marked notifications as read for user %s", user_id)
#     except Exception as e:
#         logger.error("Error marking notifications as read: %s", str(e))



import boto3
from django.conf import settings
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
import logging
from datetime import datetime
from django.contrib.auth.models import User  # Import User model

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')  # Specify your AWS region
notifications_table = dynamodb.Table('Notifications')  # Your DynamoDB table name
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_user_notifications(user_id):
    """
    Fetch unread notifications for a specific user from DynamoDB.
    """
    try:
        # Query DynamoDB for notifications that match the user_id and are unread
        response = notifications_table.query(
            KeyConditionExpression=Key('user_id').eq(user_id),
            FilterExpression=Attr('is_read').eq(False)  # This retrieves only unread notifications
        )
        notifications = response.get('Items', [])
        
        # Log the number of notifications found
        print(f"Fetched {len(notifications)} unread notifications for user {user_id}.")
        return notifications

    except Exception as e:
        logger.error("Error fetching notifications for user %s: %s", user_id, str(e))
        return []


def mark_notifications_as_read(user_id):
    """
    Marks all unread notifications for a specific user as read.
    """
    try:
        # Scan for unread notifications
        response = notifications_table.scan(
            FilterExpression=Attr('user_id').eq(user_id) & Attr('is_read').eq(False)
        )
        
        for notification in response.get('Items', []):
            # Update each notification's `is_read` attribute to True
            notifications_table.update_item(
                Key={
                    'user_id': user_id,
                    'notification_id': notification['notification_id']
                },
                UpdateExpression="SET is_read = :val",
                ExpressionAttributeValues={':val': True}
            )
        print(f"Marked notifications read for user {user_id}.")
    except Exception as e:
        logger.error("Error marking notifications as read for user %s: %s", user_id, str(e))

# def create_notifications_for_all_users(property_id, old_price, new_price):
#     """
#     Retrieve all users and create notifications in DynamoDB for a property price drop.
#     """
#     message = f"The price of a property has dropped from ${old_price} to ${new_price}! Check it out!"

#     # Fetch all user IDs
#     all_users = User.objects.values_list('id', flat=True)
#     print("Fetched user IDs for notifications:", list(all_users))  # Log all user IDs


#     for user_id in all_users:
#         print(f"Creating notification for user {user_id}")  # Log each user ID before creating notification
#         try:
#             notification_id = get_next_notification_id(user_id)
#             notifications_table.put_item(
#                 Item={
#                     'user_id': str(user_id),
#                     'notification_id': notification_id,
#                     'property_id': str(property_id),
#                     'message': message,
#                     'is_read': False,
#                     'timestamp': datetime.utcnow().isoformat()
#                 }
#             )
#             print(f"Notification created successfully for user {user_id}")

#         except ClientError as e:
#             print(f"ClientError while creating notification for user {user_id}: {e.response['Error']['Message']}")
#         except Exception as e:
#             print(f"Error creating notification for user {user_id}: {str(e)}")
        
#     print("Completed creating notifications for all users.")



# def get_next_notification_id(user_id):
#     """
#     Retrieve the next notification ID for a user by finding the highest current ID and adding one.
#     """
#     try:
#         response = notifications_table.query(
#             KeyConditionExpression=Key('user_id').eq(str(user_id)),
#             ProjectionExpression='notification_id'
#         )
#         items = response.get('Items', [])
#         max_id = max(int(item['notification_id']) for item in items) if items else 0
#         return str(max_id + 1)
        
#     except ClientError as e:
#         print(f"ClientError while fetching notifications for user {user_id}: {e.response['Error']['Message']}")
#         return "1"  # Default to '1' if query fails or no items found
#     except Exception as e:
#         print(f"Error fetching notifications for user {user_id}: {str(e)}")
#         return "1"

