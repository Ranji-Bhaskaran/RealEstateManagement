from django.contrib import admin
from .models import Property, Favorite

admin.site.register(Property)
admin.site.register(Favorite)
