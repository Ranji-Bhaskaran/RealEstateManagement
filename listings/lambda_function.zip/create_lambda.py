import boto3

# Initialize a Boto3 client for Lambda
lambda_client = boto3.client('lambda', region_name='us-east-1')  # Replace with your region

# Read the deployment package
with open('function.zip', 'rb') as f:
    zip_file = f.read()

# Create the Lambda function
response = lambda_client.create_function(
    FunctionName='MyLambdaFunction2',  # Replace with your function name
    Role='arn:aws:iam::533267406417:role/LabRole',  # Your IAM role ARN
    Handler='lambda_function.lambda_handler',  # Format: file_name.function_name
    Runtime='python3.9',  # Specify the runtime (e.g., python3.9)
    Code={
        'ZipFile': zip_file
    },
    Description='A Lambda function to call in App notification',
    Timeout=15,  # Maximum time in seconds the function can run
    MemorySize=128,  # Memory allocated to the function
    Publish=True  # Publish the function version
)

# Print the response
print(response)